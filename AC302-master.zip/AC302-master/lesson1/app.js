console.log("Testing, 1 2 3");

$('#light').click(function(){
	$('body').css('background-color', "powderblue");
	$('.boxes').css('background-color', "cornsilk");
	$('.content').css('background-color', "PeachPuff");
	$('body').css('color', "navy");
})

$('#dark').click(function(){
	$('body').css('background-color', "black");
	$('.boxes').css('background-color', "navy");
	$('.content').css('background-color', "Indigo");
	$('body').css('color', "white");
})