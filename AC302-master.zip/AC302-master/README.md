# AC302
HTML5 &amp; Phaser

* [Lesson 1 - My Gallery](https://first-code-academy.github.io/AC302/lesson1/)
* [Lesson 2 - Canvas Shapes I](https://first-code-academy.github.io/AC302/lesson2/)
* [Lesson 3 - Canvas Shapes II](https://first-code-academy.github.io/AC302/lesson3/)
* [Lesson 4 - Canvas Scenery](https://first-code-academy.github.io/AC302/lesson4/)
* [Lesson 5 - Bouncing Ball](https://first-code-academy.github.io/AC302/lesson5/)
* [Lesson 6 - Pacman](https://first-code-academy.github.io/AC302/lesson6/)
* [Lesson 7 - Phaser Part 1](https://first-code-academy.github.io/AC302/lesson7/)
* [Lesson 8 - Phaser Part 2](https://first-code-academy.github.io/AC302/lesson8/)
* [Lesson 9 - Phaser Part 3](https://first-code-academy.github.io/AC302/lesson9/)
* [Lesson 10 - Phaser Challenges/Extensions](https://first-code-academy.github.io/AC302/lesson10/)
