console.log("test....");

var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");

